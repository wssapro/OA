CREATE TABLE `user` (
  `userId` INT(11) NOT NULL AUTO_INCREMENT,
  `userNum` CHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userName` CHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `roleId` INT(11) DEFAULT NULL,
  `departmentId` INT(11) DEFAULT NULL,
  `userPassword` CHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userPhone` CHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `userAddress` CHAR(50) DEFAULT NULL,
  `userEmail` CHAR(50) DEFAULT NULL,
  `userEntrytime` DATE DEFAULT NULL,
  `userRemark` CHAR(200) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=INNODB DEFAULT CHARSET=utf8

INSERT INTO USER VALUE(NULL,'NJ000','admin' ,0,0,'1234','13954685214','上海','admin@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ001','王顺'  ,1,1,'1234','13954685214','江苏','ws@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ002','马云'  ,2,1,'1234','13596254862','杭州','my@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ003','马化腾',2,1,'1234','16585412563','深圳','mht@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ004','任正非',3,2,'1234','13158452152','北京','rzf@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ005','刘强东',3,3,'1234','13954685214','江苏','lqd@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ006','雷军'  ,3,4,'1234','18963565214','湖北','lj@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ007','丁磊'  ,3,5,'1234','13954852155','北京','dl@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ008','张朝阳',4,3,'1234','15288856545','北京','zcy@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ009','李彦宏',4,2,'1234','18856253569','北京','lyh@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ010','王思聪',4,3,'1234','13954856321','四川','wsc@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ011','王健林',4,4,'1234','15269545635','四川','wjl@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ012','史玉柱',4,5,'1234','15965485265','安徽','syz@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ013','罗永浩',4,2,'1234','13654852325','吉林','lyh@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ014','王卫'  ,4,3,'1234','13658965412','上海','ww@163.com','2018-09-26','s');
INSERT INTO USER VALUE(NULL,'NJ015','贾跃亭',4,4,'1234','13654852145','北京','jyt@163.com','2018-09-26','s');



CREATE TABLE `department` (
  `departmentId` INT(11) NOT NULL AUTO_INCREMENT,
  `departmentName` CHAR(50) NOT NULL,
  `departmentManager` INT(10) NOT NULL,
  `departmentDescription` CHAR(200) DEFAULT NULL,
  PRIMARY KEY (`departmentId`)
) ENGINE=INNODB DEFAULT CHARSET=utf8

insert into `department` (`departmentId`, `departmentName`, `departmentManager`, `departmentDescription`) values('1','董事会','2',NULL);
insert into `department` (`departmentId`, `departmentName`, `departmentManager`, `departmentDescription`) values('2','研发部','5',NULL);
insert into `department` (`departmentId`, `departmentName`, `departmentManager`, `departmentDescription`) values('3','销售部','6',NULL);
insert into `department` (`departmentId`, `departmentName`, `departmentManager`, `departmentDescription`) values('4','事务部','7',NULL);
insert into `department` (`departmentId`, `departmentName`, `departmentManager`, `departmentDescription`) values('5','人事部','8',NULL);

CREATE TABLE `role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` char(50) NOT NULL,
  `roleDescription` char(200) DEFAULT NULL,
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

insert into `role` (`roleId`, `roleName`, `roleDescription`) values('1','管理员',NULL);
insert into `role` (`roleId`, `roleName`, `roleDescription`) values('2','董事长',NULL);
insert into `role` (`roleId`, `roleName`, `roleDescription`) values('3','总经理',NULL);
insert into `role` (`roleId`, `roleName`, `roleDescription`) values('4','部长',NULL);
insert into `role` (`roleId`, `roleName`, `roleDescription`) values('5','职员',NULL);




CREATE TABLE `aothority` (
  `aothorityId` int(11) NOT NULL AUTO_INCREMENT,
  `aothorityName` char(50) NOT NULL,
  `aothorityDescription` char(200) DEFAULT NULL,
  PRIMARY KEY (`aothorityId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8





















