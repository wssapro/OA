package cn.ws.oa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.ws.common.utils.Page;
import cn.ws.oa.pojo.Department;
import cn.ws.oa.pojo.Role;
import cn.ws.oa.pojo.UserList;
import cn.ws.oa.pojo.UserQueryVo;
import cn.ws.oa.service.DepartmentService;
import cn.ws.oa.service.RoleService;
import cn.ws.oa.service.UserService;
@Controller
public class AddressController {

	@Autowired
	private UserService userService;
	@Autowired
	private RoleService roleService;
	@Autowired
	private DepartmentService departmentService;
	
	@RequestMapping(value = "/addressList.action")
	public String userList(UserQueryVo vo,Model model) {
		Page<UserList> page = userService.selectPageByVo(vo);
		model.addAttribute("page", page);
		List<Role> roleList=roleService.queryAll();
		model.addAttribute("roleList", roleList);
		List<Department> departmentList=departmentService.queryAll();
		model.addAttribute("departmentList", departmentList);
		
		model.addAttribute("userName", vo.getUserName());
		model.addAttribute("userNum", vo.getUserNum());
		model.addAttribute("roleId", vo.getRoleId());
		model.addAttribute("departmentId", vo.getDepartmentId());
		return "addressList";
	}
}
