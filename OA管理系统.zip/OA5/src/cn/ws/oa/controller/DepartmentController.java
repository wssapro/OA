package cn.ws.oa.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.ws.common.utils.Page;
import cn.ws.oa.mapper.UserMapper;
import cn.ws.oa.pojo.Department;
import cn.ws.oa.pojo.DepartmentList;
import cn.ws.oa.pojo.DepartmentQueryVo;
import cn.ws.oa.pojo.User;
import cn.ws.oa.service.DepartmentService;

@Controller
public class DepartmentController {
	@Autowired
	private DepartmentService departmentService;
	/**
	 * 分页显示
	 * @param vo
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/departmentList.action")
	public String departmentList(DepartmentQueryVo vo,Model model) {
		Page<DepartmentList> page = departmentService.selectPageByVo(vo);
		model.addAttribute("page", page);
		model.addAttribute("departmentName", vo.getDepartmentName());
		model.addAttribute("userName", vo.getUserName());
		return "departmentList";
	}
	/**
	 * 删除部门
	 * @param departmentId
	 * @return
	 */
	@RequestMapping(value = "/deleteDepartment.action")
	public @ResponseBody
	String deletDepartment(Integer departmentId) {
		departmentService.deleteDepartment(departmentId);
		return "OK"; 
	}

	@Autowired
	private UserMapper userMapper; 
	/**
	 * 添加部门
	 * @param departmentList
	 * @return
	 */
	@RequestMapping(value = "/addDepartment.action")
	public @ResponseBody
	String addDepartment(DepartmentList departmentList) {
		Department department=new Department();
		department.setDepartmentManager(userMapper.selectUserByName(departmentList.getUserName()).getUserId());
		department.setDepartmentName(departmentList.getDepartmentName());
		department.setDepartmentRemark(departmentList.getDepartmentRemark());
		departmentService.addDepartment(department);
		return "OK"; 
	}
	/**
	 * 修改回显
	 * @param departmentId
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/toUpdateDepartment.action")
	public @ResponseBody
	DepartmentList toUpdateDepartment(Integer departmentId,Model model) {
		Department department =departmentService.selectDepartmentById(departmentId);
		DepartmentList departmentList=new DepartmentList();
		departmentList.setDepartmentId(department.getDepartmentId());
		departmentList.setDepartmentName(department.getDepartmentName());
		departmentList.setUserName(userMapper.selectUserById(department.getDepartmentManager()).getUserName());
		departmentList.setDepartmentRemark(department.getDepartmentRemark());
		return departmentList; 
	}
	/**
	 * 修改部门信息
	 * @param departmentList
	 * @return
	 */
	@RequestMapping(value = "/updateDepartment.action")
	public @ResponseBody
	String updateDepartment(DepartmentList departmentList) {
		Department department=new Department();
		department.setDepartmentId(departmentList.getDepartmentId());
		department.setDepartmentName(departmentList.getDepartmentName());
		department.setDepartmentManager(userMapper.selectUserByName(departmentList.getUserName()).getUserId());
		department.setDepartmentRemark(departmentList.getDepartmentRemark());
		departmentService.updateDepartment(department);
		return "OK"; 
	}


}
