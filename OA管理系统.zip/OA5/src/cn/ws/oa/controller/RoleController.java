package cn.ws.oa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.ws.common.utils.Page;
import cn.ws.oa.pojo.Aothority;
import cn.ws.oa.pojo.AothorityAndIs;
import cn.ws.oa.pojo.Department;
import cn.ws.oa.pojo.DepartmentList;
import cn.ws.oa.pojo.QueryVo;
import cn.ws.oa.pojo.Role;
import cn.ws.oa.pojo.RoleAndAoth;
import cn.ws.oa.service.AothorityService;
import cn.ws.oa.service.RoleAndAothService;
import cn.ws.oa.service.RoleService;

@Controller
public class RoleController {

	@Autowired
	private RoleService roleService;
	@Autowired
	private AothorityService aothorityService;
	@Autowired
	private RoleAndAothService roleAndAothService;
	
	@RequestMapping( value = "roleList.action")
	public String roleList(QueryVo vo , Model model) {
		Page<Role> page = roleService.queryRoleByVo(vo);
		model.addAttribute("page", page);
		return "roleList";
	}
	@RequestMapping( value = "addRole.action")
	public @ResponseBody
	String addRole(Role role) {
		roleService.addRole(role);
		return "OK";
	}
	@RequestMapping( value = "deleteRole.action")
	public @ResponseBody
	String deleteRole(Integer roleId) {
		roleService.deleteRole(roleId);
		return "OK";
	}
	@RequestMapping(value = "/toUpdateRole.action")
	public @ResponseBody
	Role toUpdateDepartment(Integer roleId,Model model) {
		Role role = roleService.queryById(roleId);
		System.out.println(role.toString());
		return role; 
	}
	@RequestMapping(value = "/updateRole.action")
	public @ResponseBody
	String updateDepartment(Role role) {
		roleService.updateRole(role);
		return "OK"; 
	}
	@RequestMapping(value = "/showRoleAndAoth.action")
	public @ResponseBody
	Map<Integer,AothorityAndIs> showRoleAndAoth(Integer roleId, Model model) {
		List<Aothority> aothorityList = aothorityService.queryAll();
		model.addAttribute("aothorityList", aothorityList);
		
		List<Integer> roleAndAothList = roleAndAothService.queryByRoleId(roleId);
		Map<Integer,AothorityAndIs> result = new HashMap<Integer,AothorityAndIs>();
		
		for(int i=0;i<aothorityList.size();i++) {
			AothorityAndIs aothorityAndIs=new AothorityAndIs();
			Aothority aothority = aothorityList.get(i);
			aothorityAndIs.setAothority(aothority);
			if(roleAndAothList.contains(aothorityList.get(i).getAothorityId())) {
				aothorityAndIs.setIsChecked(1);
			}else {
				aothorityAndIs.setIsChecked(-1);
			}
			result.put(aothorityList.get(i).getAothorityId(),aothorityAndIs);
		}
		
		model.addAttribute("result", result);
		return result;
	}
	@RequestMapping(value = "updateRoleAndAoth.action")
	public @ResponseBody
	String updateRoleAndAoth(@RequestParam( value = "check_val[]") Integer check_val[], @RequestParam( value = "roleId") Integer roleId) {
		roleAndAothService.deleteRoleAndAoth(roleId);
		System.out.println("-------------------------------------");
		for(int i=0;i<check_val.length;i++){
			RoleAndAoth roleAndAoth=new RoleAndAoth(roleId, check_val[i]);
			roleAndAothService.insertRoleAndAoth(roleAndAoth);
		}
		return "OK";
	}
}
