package cn.ws.oa.controller;
import java.util.List;

import javax.xml.ws.RespectBinding;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.ws.common.utils.Page;
import cn.ws.oa.pojo.Department;
import cn.ws.oa.pojo.Role;
import cn.ws.oa.pojo.User;
import cn.ws.oa.pojo.UserList;
import cn.ws.oa.pojo.UserQueryVo;
import cn.ws.oa.service.DepartmentService;
import cn.ws.oa.service.RoleService;
import cn.ws.oa.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private RoleService roleService;
	@Autowired
	private DepartmentService departmentService;
	
	@RequestMapping(value = "/userList.action")
	public String userList(UserQueryVo vo,Model model) {
		Page<UserList> page = userService.selectPageByVo(vo);
		model.addAttribute("page", page);
		List<Role> roleList=roleService.queryAll();
		model.addAttribute("roleList", roleList);
		List<Department> departmentList=departmentService.queryAll();
		model.addAttribute("departmentList", departmentList);
		
		model.addAttribute("userName", vo.getUserName());
		model.addAttribute("userNum", vo.getUserNum());
		model.addAttribute("roleId", vo.getRoleId());
		model.addAttribute("departmentId", vo.getDepartmentId());
		return "userList";
	}
	@RequestMapping(value = "/toUserAdd.action")
	public String toUserAdd(Model model) {
		List<Role> roleList=roleService.queryAll();
		model.addAttribute("roleList", roleList);
		List<Department> departmentList=departmentService.queryAll();
		model.addAttribute("departmentList", departmentList);
		return "userAdd";
	}
	@RequestMapping(value = "/userAdd.action")
	public String userAdd(User user , Model model) {
		user.setUserPassword("1234");
		userService.insertUser(user);
		return "redirect:/userList.action"; 
	}
	@RequestMapping(value = "/deleteUser.action")
	public @ResponseBody
	String deletUser(Integer userId) {
		userService.userDelete(userId);
		return "OK"; 
	}
	@RequestMapping(value = "/toUpdateUser.action")
	public String toUpdateUser(Integer userId,Model model) {
		List<Role> roleList=roleService.queryAll();
		model.addAttribute("roleList", roleList);
		List<Department> departmentList=departmentService.queryAll();
		model.addAttribute("departmentList", departmentList);
		System.out.println("************:"+userId);
		User user=new User();
		user=userService.selectUserById(userId);
		model.addAttribute("user", user);
		return "userUpdate";
	}
	@RequestMapping(value = "/updateUser.action")
	public String updateUser(User user,Model model) {
		System.out.println("**************************************");
		System.out.println(user.toString());
		userService.updateUser(user);
		return "redirect:/userList.action";
	}
}
