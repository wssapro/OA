package cn.ws.oa.mapper;

import java.util.List;

import cn.ws.oa.pojo.Aothority;

public interface AothorityMapper {
	public List<Aothority> queryAll();
}
