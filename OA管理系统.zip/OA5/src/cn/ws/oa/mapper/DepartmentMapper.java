package cn.ws.oa.mapper;

import java.util.List;

import cn.ws.oa.pojo.Department;
import cn.ws.oa.pojo.DepartmentList;
import cn.ws.oa.pojo.DepartmentQueryVo;
import cn.ws.oa.pojo.User;


public interface DepartmentMapper {

	/**
	 * 查询所有
	 * @return
	 */
	List<Department> queryAll();
	/**
	 * 统计个数
	 * @return
	 */
	public Integer departmentCountByVo(DepartmentQueryVo vo);
	/**
	 * 按条件查询
	 * @param vo
	 * @return
	 */
	public List<DepartmentList> selectDepartmentListByVo(DepartmentQueryVo vo);
	/**
	 * 按编号删除部门
	 * @param departmentId
	 */
	public void deleteDepartment(Integer departmentId);
	/**
	 * 添加部门
	 * @param department
	 */
	public void addDepartment(Department department);
	/**
	 * 修改部门
	 * @param department
	 */
	public void updateDepartment(Department department);
	/**
	 * 按id查找
	 * @param departmentId
	 * @return
	 */
	public Department selectDepartmentById(Integer departmentId);
}
