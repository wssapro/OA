package cn.ws.oa.mapper;

import java.util.List;

import cn.ws.oa.pojo.RoleAndAoth;

public interface RoleAndAothMapper {

	public Integer queryOne(RoleAndAoth roleAndAoth);
	
	public List<Integer> queryByRoleId(Integer roleId);
	
	public void deleteRoleAndAoth(Integer roleId);
	
	public void insertRoleAndAoth(RoleAndAoth roleAndAoth);
}
