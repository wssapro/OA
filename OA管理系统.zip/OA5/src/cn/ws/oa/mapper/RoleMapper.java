package cn.ws.oa.mapper;

import java.util.List;

import cn.ws.oa.pojo.QueryVo;
import cn.ws.oa.pojo.Role;
import cn.ws.oa.pojo.UserQueryVo;

public interface RoleMapper {
	
	public List<Role> queryAll();
	
	public List<Role> queryRoleByVo(QueryVo vo);
	
	public void insertRole(Role role);
	
	public Integer roleCountByVo(QueryVo vo);
	
	public void deleteRole(Integer roleId);
	
	public Role queryById(Integer roleId);
	
	public void updateRole(Role role);
}
