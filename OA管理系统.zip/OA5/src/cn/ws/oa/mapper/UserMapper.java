package cn.ws.oa.mapper;

import java.util.List;

import cn.ws.oa.pojo.User;
import cn.ws.oa.pojo.UserList;
import cn.ws.oa.pojo.UserQueryVo;


public interface UserMapper {
	public User selectUserById(Integer userId);
	//结果集
	public List<UserList> selectUserListByVo(UserQueryVo vo);
	
	public Integer userCountByVo(UserQueryVo vo);
	
	public void insertUser(User user);
	
	public void deleteUser(Integer userId);
	
	public void updateUser(User user);
	
	public User selectUserByName(String userName);
	
	public User selectUserByNum(String userName);
	
}
