package cn.ws.oa.pojo;

public class Aothority {
	private Integer aothorityId;

    private String aothorityName;

    private String aothorityDescription;

	public Integer getAothorityId() {
		return aothorityId;
	}

	public void setAothorityId(Integer aothorityId) {
		this.aothorityId = aothorityId;
	}

	public String getAothorityName() {
		return aothorityName;
	}

	public void setAothorityName(String aothorityName) {
		this.aothorityName = aothorityName;
	}

	public String getAothorityDescription() {
		return aothorityDescription;
	}

	public void setAothorityDescription(String aothorityDescription) {
		this.aothorityDescription = aothorityDescription;
	}

	@Override
	public String toString() {
		return "Aothority [aothorityId=" + aothorityId + ", aothorityName=" + aothorityName + ", aothorityDescription="
				+ aothorityDescription + "]";
	}

    
    
    
    
}
