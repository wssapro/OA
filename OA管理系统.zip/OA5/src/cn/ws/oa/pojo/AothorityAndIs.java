package cn.ws.oa.pojo;

public class AothorityAndIs{

	private Integer isChecked;
	
	private Aothority aothority;

	public Integer getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Integer isChecked) {
		this.isChecked = isChecked;
	}

	public Aothority getAothority() {
		return aothority;
	}

	public void setAothority(Aothority aothority) {
		this.aothority = aothority;
	}
	
}
