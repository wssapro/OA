package cn.ws.oa.pojo;

public class Department {
	private Integer departmentId;

    private String departmentName;

    private Integer departmentManager;

    private String departmentRemark;

    
    
    public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName == null ? null : departmentName.trim();

	}

	public Integer getDepartmentManager() {
		return departmentManager;
	}

	public void setDepartmentManager(Integer departmentManager) {
		 this.departmentManager = departmentManager;
	}


	public String getDepartmentRemark() {
		return departmentRemark;
	}

	public void setDepartmentRemark(String departmentRemark) {
		this.departmentRemark = departmentRemark;
	}

	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName
				+ ", departmentManager=" + departmentManager + ", departmentDescription=" + departmentRemark + "]";
	}

    


    
    
}
