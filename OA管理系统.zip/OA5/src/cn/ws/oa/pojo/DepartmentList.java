package cn.ws.oa.pojo;

public class DepartmentList {

	private Integer departmentId;

    private String departmentName;

    private String userName;

    private String departmentRemark;

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	

	public String getDepartmentRemark() {
		return departmentRemark;
	}

	public void setDepartmentRemark(String departmentRemark) {
		this.departmentRemark = departmentRemark;
	}

	@Override
	public String toString() {
		return "DepartmentList [departmentId=" + departmentId + ", departmentName=" + departmentName + ", userName="
				+ userName + ", departmentRemark=" + departmentRemark + "]";
	}


    
    
    
    
    
}
