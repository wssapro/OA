package cn.ws.oa.pojo;

import java.util.List;

public class Role {

	private Integer roleId;

    private String roleName;

    private String roleDescription;
    
    private List<Aothority> roleAndAoth; 

    public List<Aothority> getRoleAndAoth() {
		return roleAndAoth;
	}

	public void setRoleAndAoth(List<Aothority> roleAndAoth) {
		this.roleAndAoth = roleAndAoth;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName == null ? null : roleName.trim();
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription == null ? null : roleDescription.trim();
	}

	@Override
	public String toString() {
		return "Role [roleId=" + roleId + ", roleName=" + roleName + ", roleDescription=" + roleDescription + "]";
	}



}
