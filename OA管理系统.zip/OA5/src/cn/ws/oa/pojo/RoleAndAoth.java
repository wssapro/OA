package cn.ws.oa.pojo;

public class RoleAndAoth {
	private Integer roleId;
	private Integer aothorityId;
	private String remark;
	
	
	
	public RoleAndAoth() {
		super();
	}
	public RoleAndAoth(Integer roleId, Integer aothorityId) {
		super();
		this.roleId = roleId;
		this.aothorityId = aothorityId;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public Integer getAothorityId() {
		return aothorityId;
	}
	public void setAothorityId(Integer aothorityId) {
		this.aothorityId = aothorityId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "RoleAndAoth [roleId=" + roleId + ", aothorityId=" + aothorityId + ", remark=" + remark + "]";
	}
	
	
	
	
	
	

}
