package cn.ws.oa.service;

import java.util.List;

import cn.ws.oa.pojo.Aothority;

public interface AothorityService {

	public List<Aothority> queryAll();
	
}
