package cn.ws.oa.service;

import java.util.List;

import cn.ws.common.utils.Page;
import cn.ws.oa.pojo.Department;
import cn.ws.oa.pojo.DepartmentList;
import cn.ws.oa.pojo.DepartmentQueryVo;
import cn.ws.oa.pojo.User;

public interface DepartmentService {
	public List<Department> queryAll();
	
	
	public Page<DepartmentList> selectPageByVo(DepartmentQueryVo vo);
	
	public Department selectDepartmentById(Integer departmentId);
	
	
	public void deleteDepartment(Integer departmentId);
	
	
	public void addDepartment(Department department);
	
	public void updateDepartment(Department department);
}
