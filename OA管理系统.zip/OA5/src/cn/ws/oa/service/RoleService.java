package cn.ws.oa.service;

import java.util.List;

import cn.ws.common.utils.Page;
import cn.ws.oa.pojo.QueryVo;
import cn.ws.oa.pojo.Role;

public interface RoleService {
	public List<Role> queryAll();
	
	
	public Page<Role> queryRoleByVo(QueryVo vo);
	
	public void addRole(Role role);
	
	public void deleteRole(Integer roleId);
	
	public Role queryById(Integer roleId);
	
	public void updateRole(Role role);
}
