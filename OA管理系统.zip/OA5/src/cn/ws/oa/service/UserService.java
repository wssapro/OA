package cn.ws.oa.service;

import cn.ws.common.utils.Page;
import cn.ws.oa.pojo.User;
import cn.ws.oa.pojo.UserList;
import cn.ws.oa.pojo.UserQueryVo;

public interface UserService {
	public Page<UserList> selectPageByVo(UserQueryVo vo);
	
	public void insertUser(User user);
	
	public void userDelete(Integer userId);
	
	public void updateUser(User user);
	
	public User selectUserById(Integer userId);
	
	
	public User selectUserByNum(String userName);
	
}
