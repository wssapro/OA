package cn.ws.oa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.ws.oa.mapper.AothorityMapper;
import cn.ws.oa.pojo.Aothority;
import cn.ws.oa.service.AothorityService;

@Service
public class AothorityServiceImpl implements AothorityService{

	@Autowired
	private AothorityMapper aothorityMapper;
	@Override
	public List<Aothority> queryAll() {
		return aothorityMapper.queryAll();
	}

}
