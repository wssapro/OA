package cn.ws.oa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.ws.common.utils.Page;
import cn.ws.oa.mapper.DepartmentMapper;
import cn.ws.oa.pojo.Department;
import cn.ws.oa.pojo.DepartmentList;
import cn.ws.oa.pojo.DepartmentQueryVo;
import cn.ws.oa.pojo.UserList;
import cn.ws.oa.service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentMapper departmentMapper;
	/**
	 * 查找所有部门
	 */
	public List<Department> queryAll() {
		return departmentMapper.queryAll();
	}
	/**
	 * 分页显示
	 */
	public Page<DepartmentList> selectPageByVo(DepartmentQueryVo vo) {
		Page<DepartmentList> page = new Page<DepartmentList>();
		page.setSize(5);
		vo.setSize(5);
		if (null != vo) {
			// 判断当前页
			if (null != vo.getPage()) {
				page.setPage(vo.getPage());
				vo.setStartRow((vo.getPage() -1)*vo.getSize());
			}
			if(null != vo.getDepartmentName() && !"".equals(vo.getDepartmentName().trim())){
				vo.setDepartmentName(vo.getDepartmentName().trim());
			}
			if(null != vo.getUserName()&& !"".equals(vo.getUserName())){
				vo.setUserName(vo.getUserName());
			}
			//总条数
			page.setTotal(departmentMapper.departmentCountByVo(vo));
			page.setRows(departmentMapper.selectDepartmentListByVo(vo)); 
		}
		return page;
	}
	/**
	 * 删除部门
	 */
	public void deleteDepartment(Integer departmentId) {
		departmentMapper.deleteDepartment(departmentId);
		
	}
	/**
	 * 添加部门
	 */
	public void addDepartment(Department department) {
		departmentMapper.addDepartment(department);
	}
	/**
	 * 修改部门
	 */
	@Override
	public void updateDepartment(Department department) {
		departmentMapper.updateDepartment(department);
	}
	/**
	 * 按id查找 
	 */
	@Override
	public Department selectDepartmentById(Integer departmentId) {
		return departmentMapper.selectDepartmentById(departmentId);
	}
	
}
