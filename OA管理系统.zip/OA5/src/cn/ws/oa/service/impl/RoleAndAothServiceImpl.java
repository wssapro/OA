package cn.ws.oa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.ws.oa.mapper.RoleAndAothMapper;
import cn.ws.oa.pojo.RoleAndAoth;
import cn.ws.oa.service.RoleAndAothService;
@Service
public class RoleAndAothServiceImpl implements RoleAndAothService {

	@Autowired
	private RoleAndAothMapper roleAndAothMapper;
	@Override
	public Integer queryOne(RoleAndAoth roleAndAoth) {
		return roleAndAothMapper.queryOne(roleAndAoth);
	}
	@Override
	public List<Integer> queryByRoleId(Integer roleId) {
		return roleAndAothMapper.queryByRoleId(roleId);
	}
	@Override
	public void insertRoleAndAoth(RoleAndAoth roleAndAoth) {
		roleAndAothMapper.insertRoleAndAoth(roleAndAoth);
	}
	@Override
	public void deleteRoleAndAoth(Integer roleId) {
		roleAndAothMapper.deleteRoleAndAoth(roleId);
	}
}
