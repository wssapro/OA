package cn.ws.oa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.ws.common.utils.Page;
import cn.ws.oa.mapper.RoleMapper;
import cn.ws.oa.pojo.QueryVo;
import cn.ws.oa.pojo.Role;
import cn.ws.oa.pojo.UserList;
import cn.ws.oa.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleMapper rolemapper;
	public List<Role> queryAll() {
		return rolemapper.queryAll();
	}
	@Override
	public Page<Role> queryRoleByVo(QueryVo vo) {
		Page<Role> page = new Page<Role>();
		page.setSize(5);
		vo.setSize(5);
		if (null != vo) {
			// 判断当前页
			if (null != vo.getPage()) {
				page.setPage(vo.getPage());
				vo.setStartRow((vo.getPage() -1)*vo.getSize());
			}
			//总条数
			page.setTotal(rolemapper.roleCountByVo(vo));
			page.setRows(rolemapper.queryRoleByVo(vo)); 
		}
		return page;
	}
	@Override
	public void addRole(Role role) {
		rolemapper.insertRole(role);
	}
	@Override
	public void deleteRole(Integer roleId) {
		rolemapper.deleteRole(roleId);
	}
	@Override
	public Role queryById(Integer roleId) {
		return rolemapper.queryById(roleId);
	}
	@Override
	public void updateRole(Role role) {
		rolemapper.updateRole(role);
	}
}
