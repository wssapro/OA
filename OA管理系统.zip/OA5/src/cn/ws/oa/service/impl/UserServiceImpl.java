package cn.ws.oa.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.ws.common.utils.Page;
import cn.ws.oa.mapper.UserMapper;
import cn.ws.oa.pojo.User;
import cn.ws.oa.pojo.UserList;
import cn.ws.oa.pojo.UserQueryVo;
import cn.ws.oa.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserMapper userMapper; 
	public Page<UserList> selectPageByVo(UserQueryVo vo) {
		Page<UserList> page = new Page<UserList>();
		page.setSize(5);
		vo.setSize(5);
		if (null != vo) {
			// 判断当前页
			if (null != vo.getPage()) {
				page.setPage(vo.getPage());
				vo.setStartRow((vo.getPage() -1)*vo.getSize());
			}
			if(null != vo.getUserName() && !"".equals(vo.getUserName().trim())){
				vo.setUserName(vo.getUserName().trim());
			}
			if(null != vo.getUserNum()&& !"".equals(vo.getUserNum())){
				vo.setUserNum(vo.getUserNum());
			}
			if(null != vo.getRoleId()){
				vo.setRoleId(vo.getRoleId());
			}
			if(null != vo.getDepartmentId()){
				vo.setDepartmentId(vo.getDepartmentId());
			}
			//总条数
			page.setTotal(userMapper.userCountByVo(vo));
			page.setRows(userMapper.selectUserListByVo(vo)); 
		}
		
		return page;
	}
	
	@Override
	public void insertUser(User user) {
		userMapper.insertUser(user);
	}
	@Override
	public void userDelete(Integer userId) {
		userMapper.deleteUser(userId);
	}

	@Override
	public void updateUser(User user) {
		userMapper.updateUser(user);
	}

	@Override
	public User selectUserById(Integer userId) {
		return userMapper.selectUserById(userId);
	}

	@Override
	public User selectUserByNum(String userName) {
		return userMapper.selectUserByNum(userName);
	}

}
