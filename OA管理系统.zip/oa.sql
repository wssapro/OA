/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80013
 Source Host           : localhost:3306
 Source Schema         : oa

 Target Server Type    : MySQL
 Target Server Version : 80013
 File Encoding         : 65001

 Date: 08/01/2019 17:32:25
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for aothority
-- ----------------------------
DROP TABLE IF EXISTS `aothority`;
CREATE TABLE `aothority`  (
  `aothorityId` int(11) NOT NULL AUTO_INCREMENT,
  `aothorityName` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `aothorityDescription` char(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`aothorityId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of aothority
-- ----------------------------
INSERT INTO `aothority` VALUES (1, '添加用户', NULL);
INSERT INTO `aothority` VALUES (2, '修改用户', NULL);
INSERT INTO `aothority` VALUES (3, '删除用户', NULL);
INSERT INTO `aothority` VALUES (4, '添加部门', NULL);
INSERT INTO `aothority` VALUES (5, '修改部门', NULL);
INSERT INTO `aothority` VALUES (6, '删除部门', NULL);
INSERT INTO `aothority` VALUES (7, '添加角色', NULL);
INSERT INTO `aothority` VALUES (8, '修改角色', NULL);
INSERT INTO `aothority` VALUES (9, '删除角色', NULL);
INSERT INTO `aothority` VALUES (10, '添加权限', NULL);
INSERT INTO `aothority` VALUES (11, '修改权限', NULL);
INSERT INTO `aothority` VALUES (12, '删除权限', NULL);

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `departmentId` int(11) NOT NULL AUTO_INCREMENT,
  `departmentName` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `departmentManager` int(10) NOT NULL,
  `departmentRemark` char(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`departmentId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '董事会', 2, '。00');
INSERT INTO `department` VALUES (2, '研发部', 5, 'aaaa');
INSERT INTO `department` VALUES (3, '销售部', 6, NULL);
INSERT INTO `department` VALUES (4, '事务部', 7, NULL);
INSERT INTO `department` VALUES (5, '人事部', 8, NULL);
INSERT INTO `department` VALUES (7, 'ASDASD', 17, 'ASDASD');
INSERT INTO `department` VALUES (8, '测试', 2, 'asdasd');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `roleDescription` char(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`roleId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, '管理员', '一切权限');
INSERT INTO `role` VALUES (2, '董事长', NULL);
INSERT INTO `role` VALUES (3, '总经理', NULL);
INSERT INTO `role` VALUES (4, '部长', NULL);
INSERT INTO `role` VALUES (5, '职员', '少');
INSERT INTO `role` VALUES (6, '实习生', NULL);

-- ----------------------------
-- Table structure for roleandaoth
-- ----------------------------
DROP TABLE IF EXISTS `roleandaoth`;
CREATE TABLE `roleandaoth`  (
  `roleId` int(10) NOT NULL,
  `aothorityId` int(10) NOT NULL,
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`roleId`, `aothorityId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of roleandaoth
-- ----------------------------
INSERT INTO `roleandaoth` VALUES (1, 1, NULL);
INSERT INTO `roleandaoth` VALUES (1, 2, NULL);
INSERT INTO `roleandaoth` VALUES (1, 3, NULL);
INSERT INTO `roleandaoth` VALUES (1, 4, NULL);
INSERT INTO `roleandaoth` VALUES (1, 5, NULL);
INSERT INTO `roleandaoth` VALUES (1, 6, NULL);
INSERT INTO `roleandaoth` VALUES (1, 7, NULL);
INSERT INTO `roleandaoth` VALUES (1, 8, NULL);
INSERT INTO `roleandaoth` VALUES (1, 9, NULL);
INSERT INTO `roleandaoth` VALUES (1, 10, NULL);
INSERT INTO `roleandaoth` VALUES (1, 11, NULL);
INSERT INTO `roleandaoth` VALUES (1, 12, NULL);
INSERT INTO `roleandaoth` VALUES (2, 1, NULL);
INSERT INTO `roleandaoth` VALUES (2, 2, NULL);
INSERT INTO `roleandaoth` VALUES (2, 3, NULL);
INSERT INTO `roleandaoth` VALUES (2, 4, NULL);
INSERT INTO `roleandaoth` VALUES (2, 5, NULL);
INSERT INTO `roleandaoth` VALUES (2, 6, NULL);
INSERT INTO `roleandaoth` VALUES (2, 7, NULL);
INSERT INTO `roleandaoth` VALUES (2, 8, NULL);
INSERT INTO `roleandaoth` VALUES (2, 9, NULL);
INSERT INTO `roleandaoth` VALUES (2, 10, NULL);
INSERT INTO `roleandaoth` VALUES (2, 11, NULL);
INSERT INTO `roleandaoth` VALUES (2, 12, NULL);
INSERT INTO `roleandaoth` VALUES (3, 1, NULL);
INSERT INTO `roleandaoth` VALUES (3, 2, NULL);
INSERT INTO `roleandaoth` VALUES (3, 3, NULL);
INSERT INTO `roleandaoth` VALUES (3, 4, NULL);
INSERT INTO `roleandaoth` VALUES (3, 5, NULL);
INSERT INTO `roleandaoth` VALUES (3, 6, NULL);
INSERT INTO `roleandaoth` VALUES (4, 1, NULL);
INSERT INTO `roleandaoth` VALUES (4, 2, NULL);
INSERT INTO `roleandaoth` VALUES (4, 3, NULL);
INSERT INTO `roleandaoth` VALUES (5, 2, NULL);
INSERT INTO `roleandaoth` VALUES (6, 2, NULL);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userNum` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userName` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `roleId` int(11) NULL DEFAULT NULL,
  `departmentId` int(11) NULL DEFAULT NULL,
  `userPassword` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userPhone` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userAddress` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userEmail` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userEntrytime` date NULL DEFAULT NULL,
  `userRemark` char(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`userId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'NJ000', 'admin', 1, 1, '1234', '13954685214', '上海', 'admin@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (2, 'NJ001', '王顺', 2, 1, '1234', '13954685214', '江苏', 'ws@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (3, 'NJ002', '马云', 3, 1, '1234', '13596254862', '杭州', 'my@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (4, 'NJ003', '马化腾', 3, 1, '1234', '16585412563', '深圳', 'mht@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (5, 'NJ004', '任正非', 4, 2, '1234', '13158452152', '北京', 'rzf@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (6, 'NJ005', '刘强东', 4, 3, '1234', '13954685214', '江苏', 'lqd@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (7, 'NJ006', '雷军', 4, 4, '1234', '18963565214', '湖北', 'lj@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (8, 'NJ007', '丁磊', 4, 5, '1234', '13954852155', '北京', 'dl@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (9, 'NJ008', '张朝阳', 5, 3, '1234', '15288856545', '北京', 'zcy@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (10, 'NJ009', '李彦宏', 5, 2, '1234', '18856253569', '北京', 'lyh@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (11, 'NJ010', '王思聪', 5, 3, '1234', '13954856321', '四川', 'wsc@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (12, 'NJ011', '王健林', 5, 4, '1234', '15269545635', '四川', 'wjl@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (13, 'NJ012', '史玉柱', 5, 5, '1234', '15965485265', '安徽', 'syz@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (14, 'NJ013', '罗永浩', 5, 2, '1234', '13654852325', '吉林', 'lyh@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (15, 'NJ014', '王卫', 5, 3, '1234', '13658965412', '上海', 'ww@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (16, 'NJ015', '贾跃亭', 5, 4, '1234', '13654852145', '北京', 'jyt@163.com', '2018-09-26', 's');
INSERT INTO `user` VALUES (17, 'NJ11111', '张三', 1, 1, '1234', '1111', '1', '1', '2019-01-19', '1');

SET FOREIGN_KEY_CHECKS = 1;
